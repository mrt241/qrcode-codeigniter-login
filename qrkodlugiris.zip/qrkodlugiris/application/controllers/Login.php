<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    public function index(){
        $this->load->view('login_view');
    }

    public function logindata($kod){

        if(!$kod){
            redirect(base_url());
        }

        $sorgu = $this->common_model->get(['qrkodkripto'=>$kod],'uyeler');
        if($sorgu){

            $this->session->set_userdata([
                'kadi'   => $sorgu->kadi,
                'id'     => $sorgu->id,
                'eposta' => $sorgu->eposta,
                'oturum' => true
            ]);

            redirect(base_url('profile'));

        }else{
            echo "Böyle bir üye yok";
        }

    }

}

?>