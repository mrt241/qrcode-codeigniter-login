<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {


	public function index()
	{
		$this->load->view('register_view');
	}

	public function registerdata(){
		
		if($this->input->method() == "post"){

			$kadi   = $this->input->post('kadi',true);
			$eposta = $this->input->post('eposta',true);
			$sifre  = $this->input->post('sifre',true);

			$birlestir = sha1(md5($kadi.$eposta.$sifre));
			$kripto    = $birlestir.uniqid();

			$link = "http://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=".$kripto;

			$ayarlar = array(
				"ssl" => array(
					"verify_pear" => false,
					"verify_pear_name" => false
				)
			);

			$vericek = file_get_contents($link,false,stream_context_create($ayarlar));
			$dosya   = "./upload/".$kripto.".png";
			$fp      = fopen($dosya,"w");
			fwrite($fp,$vericek);
			fclose($fp);

			$data = array(
				"kadi" => $kadi,
				"eposta" => $eposta,
				"sifre"  => sha1(md5($sifre)),
				"qrkodresim" => $kripto.".png",
				"qrkodkripto" => $kripto
			);

			$ekle = $this->common_model->insert('uyeler',$data);
			if($ekle){
				echo "kayıt oluşturuldu";
			}else{
				echo "hata oluştu";
			}
			

		}

	}

	
}

?>